from ..use_cases import GetProductsCase


def get_products_case() -> GetProductsCase:
    return GetProductsCase()
