from typing import NamedTuple


class FindProductByIdRequest(NamedTuple):
    product_id: str
