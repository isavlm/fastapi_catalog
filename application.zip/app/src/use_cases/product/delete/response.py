from decimal import Decimal

from typing import NamedTuple


class DeleteProductResponse(NamedTuple):
    product_id: str