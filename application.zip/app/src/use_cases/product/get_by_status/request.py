from typing import NamedTuple

class FilterProductsByStatusRequest(NamedTuple):

    status: str