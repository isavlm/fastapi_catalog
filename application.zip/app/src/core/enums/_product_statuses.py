from enum import Enum


class ProductStatuses(Enum):
    NEW = "New"
    USED = "Used"
    FOR_PARTS = "For parts"
