from main import app

application = app
