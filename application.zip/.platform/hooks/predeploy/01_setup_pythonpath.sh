#!/bin/bash
export PYTHONPATH="/var/app/current:$PYTHONPATH"
cd /var/app/current
